
# from contextlib import asynccontextmanager

# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware
# from sqlalchemy import text

# from app.core.config import get_settings
# from app.database import Base, engine

# # Register SQLAlchemy models.
# # No __init__.py is required for these direct imports.
# import app.models.user
# import app.models.finance

# # Import the routers using their actual filenames.
# from app.routers.auth import router as auth_router
# from app.routers.onboarding import router as onboarding_router
# from app.routers.transaction import router as transaction_router
# from app.routers.dashboard import router as dashboard_router


# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     # Development setup only.
#     # This creates missing tables, not missing columns.
#     Base.metadata.create_all(bind=engine)
#     yield


# settings = get_settings()

# app = FastAPI(
#     title="MaxBud API",
#     description="MaxBud Budget Management Backend",
#     version="1.0.0",
#     lifespan=lifespan,
# )

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=[
#         settings.FRONTEND_ORIGIN,
#         "http://localhost:5173",
#         "http://127.0.0.1:5173",
#     ],
#     allow_credentials=True,
#     allow_methods=["GET", "POST", "PUT", "DELETE"],
#     allow_headers=["Authorization", "Content-Type"],
# )

# app.include_router(auth_router)
# app.include_router(onboarding_router)
# app.include_router(transaction_router)
# app.include_router(dashboard_router)


# @app.get("/")
# def home():
#     return {
#         "message": "MaxBud backend is running",
#     }


# @app.get("/health")
# def health():
#     with engine.connect() as connection:
#         connection.execute(text("SELECT 1"))

#     return {
#         "status": "ok",
#         "database": "connected",
#     }



from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.core.config import get_settings
from app.database import engine
from app.routers import (
    auth,
    dashboard,
    onboarding,
    transaction,
)


settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Verify database access without creating or changing tables.
    with engine.connect() as connection:
        connection.execute(text("SELECT 1"))

    yield

    engine.dispose()


app = FastAPI(
    title="MaxBud API",
    version="1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(
        {
            settings.FRONTEND_ORIGIN,
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        }
    ),
    allow_credentials=False,
    allow_methods=[
        "GET",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "OPTIONS",
    ],
    allow_headers=[
        "Authorization",
        "Content-Type",
    ],
)

app.include_router(auth.router)
app.include_router(onboarding.router)
app.include_router(transaction.router)
app.include_router(dashboard.router)


@app.get("/health", tags=["Health"])
def health():
    with engine.connect() as connection:
        connection.execute(text("SELECT 1"))

    return {
        "status": "ok",
        "database": "connected",
    }

