
from datetime import date
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.deps import current_user
from app.database import get_db
from app.models.finance import Account, Transaction
from app.models.user import User
from app.schemas.transaction import TransactionIn, TransactionOut

router = APIRouter(
    prefix="/transactions",
    tags=["Transactions"],
)


def find_account(
    db: Session,
    user: User,
    account_id: int,
) -> Account:
    account = db.scalar(
        select(Account)
        .where(
            Account.id == account_id,
            Account.user_id == user.id,
        )
        .with_for_update()
    )

    if account is None:
        raise HTTPException(
            status_code=404,
            detail="Account not found",
        )

    if account.currency != user.currency:
        raise HTTPException(
            status_code=422,
            detail="Account currency must match your selected currency",
        )

    return account


def find_transaction(
    db: Session,
    user: User,
    transaction_id: int,
) -> Transaction:
    transaction = db.scalar(
        select(Transaction).where(
            Transaction.id == transaction_id,
            Transaction.user_id == user.id,
        )
    )

    if transaction is None:
        raise HTTPException(
            status_code=404,
            detail="Transaction not found",
        )

    return transaction


def available_balance(
    db: Session,
    account: Account,
    exclude_transaction_id: int | None = None,
) -> Decimal:
    filters = [
        Transaction.user_id == account.user_id,
        Transaction.account_id == account.id,
    ]

    if exclude_transaction_id is not None:
        filters.append(
            Transaction.id != exclude_transaction_id
        )

    totals = db.execute(
        select(
            Transaction.kind,
            func.sum(Transaction.amount),
        )
        .where(*filters)
        .group_by(Transaction.kind)
    ).all()

    by_kind = {
        kind: Decimal(amount)
        for kind, amount in totals
    }

    return (
        Decimal(account.opening_balance)
        + by_kind.get("income", Decimal("0"))
        - by_kind.get("expense", Decimal("0"))
    )


def validate_expense_balance(
    db: Session,
    account: Account,
    data: TransactionIn,
    exclude_transaction_id: int | None = None,
) -> None:
    if (
        data.kind == "expense"
        and available_balance(
            db,
            account,
            exclude_transaction_id,
        ) < data.amount
    ):
        raise HTTPException(
            status_code=422,
            detail="Insufficient tracked account balance",
        )


@router.post(
    "",
    response_model=TransactionOut,
    status_code=201,
)
def create_transaction(
    data: TransactionIn,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    account = find_account(
        db,
        user,
        data.account_id,
    )

    validate_expense_balance(
        db,
        account,
        data,
    )

    transaction = Transaction(
        user_id=user.id,
        **data.model_dump(),
    )

    db.add(transaction)
    db.commit()
    db.refresh(transaction)

    return transaction


@router.get(
    "",
    response_model=list[TransactionOut],
)
def list_transactions(
    kind: Literal["income", "expense"] | None = None,
    category: str | None = None,
    account_id: int | None = Query(default=None, gt=0),
    start_date: date | None = None,
    end_date: date | None = None,
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if (
        start_date
        and end_date
        and start_date > end_date
    ):
        raise HTTPException(
            status_code=422,
            detail="start_date must be before end_date",
        )

    stmt = select(Transaction).where(
        Transaction.user_id == user.id
    )

    if kind:
        stmt = stmt.where(
            Transaction.kind == kind
        )

    if category and category.strip():
        stmt = stmt.where(
            func.lower(Transaction.category)
            == category.strip().lower()
        )

    if account_id:
        stmt = stmt.where(
            Transaction.account_id == account_id
        )

    if start_date:
        stmt = stmt.where(
            Transaction.txn_date >= start_date
        )

    if end_date:
        stmt = stmt.where(
            Transaction.txn_date <= end_date
        )

    stmt = stmt.order_by(
        Transaction.txn_date.desc(),
        Transaction.id.desc(),
    )

    return db.scalars(
        stmt.offset(offset).limit(limit)
    ).all()


@router.get(
    "/{transaction_id}",
    response_model=TransactionOut,
)
def get_transaction(
    transaction_id: int,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    return find_transaction(
        db,
        user,
        transaction_id,
    )


@router.put(
    "/{transaction_id}",
    response_model=TransactionOut,
)
def update_transaction(
    transaction_id: int,
    data: TransactionIn,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    transaction = find_transaction(
        db,
        user,
        transaction_id,
    )

    account = find_account(
        db,
        user,
        data.account_id,
    )

    validate_expense_balance(
        db,
        account,
        data,
        exclude_transaction_id=transaction_id,
    )

    for name, value in data.model_dump().items():
        setattr(transaction, name, value)

    db.commit()
    db.refresh(transaction)

    return transaction


@router.delete("/{transaction_id}")
def delete_transaction(
    transaction_id: int,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    transaction = find_transaction(
        db,
        user,
        transaction_id,
    )

    db.delete(transaction)
    db.commit()

    return {
        "message": "Transaction deleted",
        "id": transaction_id,
    }
